//
//  BaseViewController.h
//  菁优网首页动画
//
//  Created by JackChen on 2016/12/13.
//  Copyright © 2016年 chenlin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLOneViewController : UIViewController
- (void)back:(id)sender ;
@end
