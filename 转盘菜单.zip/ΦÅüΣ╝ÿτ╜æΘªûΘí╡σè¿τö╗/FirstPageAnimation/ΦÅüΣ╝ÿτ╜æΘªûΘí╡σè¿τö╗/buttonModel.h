//
//  buttonModel.h
//  菁优网首页动画
//
//  Created by JackChen on 2016/12/13.
//  Copyright © 2016年 chenlin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface buttonModel : NSObject

@property (nonatomic,copy) NSString *className;

@property (nonatomic,copy) NSString *title;

@property (nonatomic,copy) NSString *Image;

@end
